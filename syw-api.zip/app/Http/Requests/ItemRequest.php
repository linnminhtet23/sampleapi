<?php

namespace App\Http\Requests;

class ItemRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'code' => 'required',
            'name' => 'required',
            'left_item' => 'required',
            'buy_price' => 'required',
            'category_id' => 'required',
            'shop_id' => 'required',
        ];
    }
}
